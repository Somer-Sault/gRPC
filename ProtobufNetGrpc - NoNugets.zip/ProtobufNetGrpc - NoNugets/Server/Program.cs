﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Grpc.Core;
using ProtoBuf.Grpc.Server;
using Server.Interceptors;
using Shared;
using static Shared.Tools.CertUtil;

namespace Server
{
  class Program
  {
    /// <summary>Built-In logger https://grpc.github.io/grpc/csharp/api/Grpc.Core.Logging.html </summary>
    private static Grpc.Core.Logging.ILogger s_builtInServerLogger = new Grpc.Core.Logging.ConsoleLogger();

    // Using sample test credentials from https://github.com/grpc/grpc/tree/master/src/core/tsi/test_creds
    static async Task Main()
    {
      const string serverCertDir = @"..\..\Cert";
      // Server interceptor example
      var interceptor = new ServerCallContextInterceptor(x => 
      {
        x.RequestHeaders.Add(new Metadata.Entry("ServerInterceptor", "PASS!"));
        s_builtInServerLogger.Warning("Added header in Server interceptor");
      });


      var serverCerts = new List<KeyCertificatePair>
      {
        new KeyCertificatePair(File.ReadAllText($"{serverCertDir}\\grpcLocal.pem"), File.ReadAllText($"{serverCertDir}\\grpcLocal.key"))
      };
      var sslCredentials = new SslServerCredentials(serverCerts);
      // Verify in case of Mutual TLS
      // var sslCredentials = new SslServerCredentials(serverCerts, null, SslClientCertificateRequestType.RequestButDontVerify);

      var server = new Grpc.Core.Server
      {
        // Insecure option
         //new ServerPort("localhost", port, ServerCredentials.Insecure)

        // Secure server with ssl-enabled
        Ports = { new ServerPort("localhost", Port, sslCredentials) }
        // mow-wks-08.micromine.com.au
      };
      
      server.Services.AddCodeFirst<ICalculator>(new Calculator(), null, null/* place textwriter here*/, new[] { interceptor });
      server.Services.AddCodeFirst<IAuth>(new AuthService(), null, null, new[] { interceptor });
      server.Services.AddCodeFirst<ITimeService>(new TimeService());
      // https://github.com/grpc/grpc/issues/19905
      server.Start();

      Console.WriteLine($"Server listening on port {Port}");
      Console.ReadKey();
      await server.ShutdownAsync();
    }
  }
}
