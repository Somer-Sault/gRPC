﻿using System;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Shared.Tools
{
  /// <summary> Helper functions to work with certificates store (PROD environment)</summary>
  public static class CertUtil
  {
    /// <summary> Port </summary>
    public static int Port = 10042;

    // Trusted Root/Certificates/MicromineCA 2033
    public static string SslThumbprint = "4b049738f8620561bdedd30eba0efe79f652b5b5";

    /// <summary> Get root cert from your machine </summary>
    /// <param name="sslThumbprint">Cert fingerprint</param>
    /// <returns>PEM representation of root cert</returns>
    /// <remarks>https://github.com/angelagyang/GRPCProtobufExample/blob/master/GRPCClient/Program.cs</remarks>
    public static string GetRootCertificates(string sslThumbprint)
    {
      var builder = new StringBuilder();
      var cert = LoadSSLCertificate(sslThumbprint);
      builder.AppendLine(
              "# Issuer: " + cert.Issuer.ToString() + "\n" +
              "# Subject: " + cert.Subject.ToString() + "\n" +
              "# Label: " + cert.FriendlyName.ToString() + "\n" +
              "# Serial: " + cert.SerialNumber.ToString() + "\n" +
              "# SHA1 Fingerprint: " + cert.GetCertHashString().ToString() + "\n" +
              ExportToPEM(cert) + "\n");
      return builder.ToString();
    }

    private static X509Certificate2 LoadSSLCertificate(string sslThumbprint)
    {
      var certStore = new X509Store(StoreLocation.LocalMachine);
      certStore.Open(OpenFlags.ReadOnly);
      var cert = certStore.Certificates.Find(X509FindType.FindByThumbprint, sslThumbprint, false)[0];
      certStore.Close();
      return cert;
    }

    public static string ExportToPEM(X509Certificate cert)
    {
      StringBuilder builder = new StringBuilder();
      builder.AppendLine("-----BEGIN CERTIFICATE-----");
      builder.AppendLine(Convert.ToBase64String(cert.Export(X509ContentType.Cert), Base64FormattingOptions.InsertLineBreaks));
      builder.AppendLine("-----END CERTIFICATE-----");
      return builder.ToString();
    }
  }
}
