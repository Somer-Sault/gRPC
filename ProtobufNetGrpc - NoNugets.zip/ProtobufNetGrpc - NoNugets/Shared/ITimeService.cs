﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using ProtoBuf.Grpc;
using ProtoBuf;

namespace Shared
{
  [ServiceContract]
  public interface ITimeService
  {
    IAsyncEnumerable<TimeResult> SubscribeAsync(CallContext context);
  }

  [ProtoContract]
  public class TimeResult
  {
    [ProtoMember(1, DataFormat = DataFormat.WellKnown)]
    public DateTime Time { get; set; }
  }
}
