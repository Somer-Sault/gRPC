﻿using Shared.Dto;
using System.ServiceModel;
using System.Threading.Tasks;

namespace Shared
{

  /// <summary> Deals with apps authhentication and authorization</summary>
  [ServiceContract(Name = "Pitram6.AuthService")]
  public interface IAuth
  {
    /// <summary>Form access token based on name-password </summary>
    /// <returns>Access token </returns>
    Task<string> SignInAsync(UserRequest request);
  }
}
