﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;
using System.Threading;

using ProtoBuf.Grpc;
using Shared;

namespace Server
{
  public class TimeService : ITimeService
  {
    public IAsyncEnumerable<TimeResult> SubscribeAsync(CallContext context)=> SubscribeAsync(context.CancellationToken);

    private async IAsyncEnumerable<TimeResult> SubscribeAsync([EnumeratorCancellation] CancellationToken cancel)
    {
      while (!cancel.IsCancellationRequested)
      {
        await Task.Delay(TimeSpan.FromSeconds(5), cancel);
        yield return new TimeResult { Time = DateTime.UtcNow };
      }
    }
  }
}
