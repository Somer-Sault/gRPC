﻿using System.Runtime.Serialization;

namespace Shared.Dto
{
  [DataContract]
  public class MultiplyResult
  {
    [DataMember(Order = 1)]
    public int Result { get; set; }
  }
}
