﻿using Grpc.Core;
using Grpc.Core.Interceptors;
using Grpc.Core.Logging;
using Newtonsoft.Json;
using System;

namespace Client_47.Interceptors
{
  /// <summary>
  /// https://github.com/grpc/grpc/blob/618a3f561d4a93f263cca23abad086ed8f4d5e86/src/csharp/Grpc.Core.Tests/Interceptors/ClientInterceptorTest.cs
  /// </summary>
  public class ClientInterceptor : Interceptor
  {
    private readonly Action  m_callback;
    private readonly ILogger m_logger;

    public ClientInterceptor(Action callback =null, ILogger logger=null)
    {
      m_callback = callback;
      m_logger = logger;
    }

    public override AsyncUnaryCall<TResponse> AsyncUnaryCall<TRequest, TResponse>(TRequest request, ClientInterceptorContext<TRequest, TResponse> context, AsyncUnaryCallContinuation<TRequest, TResponse> continuation)
    {
      if (m_callback != null)
        m_callback();
      m_logger?.Debug($"{Environment.NewLine}GRPC Request Method: {context.Method.ServiceName}.{context.Method.Name}{Environment.NewLine}" +
        $"  Data: {JsonConvert.SerializeObject(request, Formatting.Indented)}");

      var rc =  continuation(request, context);
      TResponse response = rc.GetAwaiter().GetResult();

      m_logger?.Debug($"{Environment.NewLine}GRPC Response Method: {context.Method.ServiceName}.{context.Method.Name}{Environment.NewLine}" +
        $"  Data: {JsonConvert.SerializeObject(response, Formatting.Indented)}");
      return rc;
    }

    public override TResponse BlockingUnaryCall<TRequest, TResponse>(TRequest request, ClientInterceptorContext<TRequest, TResponse> context, BlockingUnaryCallContinuation<TRequest, TResponse> continuation)
    {
      if (m_callback != null)
        m_callback();
      return continuation(request, context);
    }
  }
}
