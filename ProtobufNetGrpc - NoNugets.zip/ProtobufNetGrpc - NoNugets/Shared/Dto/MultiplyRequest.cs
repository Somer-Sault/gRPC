﻿using ProtoBuf;
using System.Runtime.Serialization;

namespace Shared.Dto
{
  [DataContract]
  [ProtoInclude(3, typeof(Multiply3DRequest))]
  public class MultiplyRequest
  {
    [DataMember(Order = 1)]
    public int X { get; set; }

    [DataMember(Order = 2)]
    public int Y { get; set; }
  }

  [DataContract]
  public class Multiply3DRequest: MultiplyRequest
  {
    [DataMember(Order = 3)]
    public int Z { get; set; }
  }
}
