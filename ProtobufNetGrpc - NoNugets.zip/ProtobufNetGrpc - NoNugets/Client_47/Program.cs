﻿using Grpc.Core;
using Grpc.Core.Interceptors;
using ProtoBuf.Grpc;
using ProtoBuf.Grpc.Client;
using System;
using System.Threading.Tasks;
using Shared;
using Shared.Dto;
using System.IO;
using System.Threading;
using static Shared.Tools.CertUtil;
using Client_47.Interceptors;

namespace Client_47
{
  /// <summary>
  /// To get the client connected, you need to give it the server.crt (or server.pem) public key. 
  /// In normal operation, this key can be fetched from a certificate authority, 
  /// but since we’re doing internal RPC, the public key must be shipped with the application.
  /// It is an open question about how to manage certificates in a larger system, 
  /// but potentially an internal certificate authority resolves these problems.
  /// </summary>
  /// <remarks>https://bbengfort.github.io/programmer/2017/03/03/secure-grpc.html</remarks>
  class Program
  {
    /// <summary>Built-In logger https://grpc.github.io/grpc/csharp/api/Grpc.Core.Logging.html </summary>
    private static Grpc.Core.Logging.ILogger s_builtInLogger = new Grpc.Core.Logging.ConsoleLogger();
    //private static Grpc.Core.Logging.ILogger s_builtInLogger = new Grpc.Core.Logging.TextWriterLogger(new StreamWriter("d:\\out.txt"));

    private static void ClientCallback() => s_builtInLogger?.Info("Hi from client interceptor!");

    static async Task Main(string[] args)
    {
      s_builtInLogger?.Warning("Waiting for server to initialize");
      await Task.Delay(1000);
      s_builtInLogger?.Info("Starting");

      string certDir = $"{Directory.GetCurrentDirectory()}/../../Cert";
      string rootDir = $"{Directory.GetCurrentDirectory()}/../../../Server/Cert";
      // Self signed server cert generated on my machine
      string serverCert = File.ReadAllText($"{rootDir}/grpcLocal.pem");
      // Self signed client cert from  https://github.com/grpc/grpc/tree/master/src/core/tsi/test_creds
      string clientCert = File.ReadAllText($"{certDir}/client.pem");
      string clientKey  = File.ReadAllText($"{certDir}/client.key");

      // native grpc cc-lib logging - uses console as a default output
      //Environment.SetEnvironmentVariable("GRPC_TRACE", "api");
      //Environment.SetEnvironmentVariable("GRPC_VERBOSITY", "debug");
      // Register the logger in Grpc
      Grpc.Core.GrpcEnvironment.SetLogger(s_builtInLogger);

      // Server-side TLS - client needs to have server CA cert or server cert (just PEM without no server's private key)
      var channelCredentials = new SslCredentials(serverCert);

      // Mutual TLS - https://dev.to/techschoolguru/how-to-secure-grpc-connection-with-ssl-tls-in-go-4ph
      //var clientCertPair = new KeyCertificatePair(clientCert, clientKey);
      //var channelCredentials = new SslCredentials(serverCert, clientCertPair, verifyPeerCallback => true);
      // DontRequest on Server => no need client's keyCertPair
      // Insecure - use ChannelCredentials.Insecure
      // Heavy-object, create it once and for all
      var channel = new Channel("localhost", Port, channelCredentials);

      // Multiple interceptors can be added on top of each other by calling "invoker.Intercept(a, b, c)".
      // The order of invocation will be "a", "b", and then "c".Interceptors can be later added to an existing intercepted CallInvoker,
      // effectively building a chain like "invoker.Intercept(c).Intercept(b).Intercept(a)".Note that in this case,
      // the last interceptor added will be the first to take control.
      CallInvoker callInvoker = channel.Intercept(new ClientInterceptor(ClientCallback, s_builtInLogger));
      

      try
      {
        // Light-weights objects, can be created when needed
        // Use callInvoker if interceptions is needed
        IAuth auth = callInvoker.CreateGrpcService<IAuth>();
        ICalculator calculator = callInvoker.CreateGrpcService<ICalculator>();

        // Called once, for ex
        string accessToken = await auth.SignInAsync(new UserRequest { Name = "pitram", Password = "secret"});

        // Test1 for unary async call
        // From Grpc.Core library
        var options = new CallOptions(new Metadata {{ "SomeHeader", "SomeHeaderValue" }},
          null, // Deadline - how long client is willing to wait for a reply from the server.
          new CancellationTokenSource(TimeSpan.FromMinutes(1)).Token,
          null,//new WriteOptions(WriteFlags.BufferHint | WriteFlags.NoCompress),
          null,
          CallCredentials.FromInterceptor(AccessTokenInterceptor(accessToken)));
        // If you want more control and brevity, specify smth you are interested in
        //options.WithCredentials(CallCredentials.FromInterceptor(AccessTokenInterceptor(accessToken)))

        // Magic Bag (state) - 
        object? state = "123";
        CallContext context = new CallContext(options, CallContextFlags.CaptureMetadata, state);

        MultiplyResult result = await calculator.MultiplyAsync(new MultiplyRequest { X = 15, Y = 3 }, context);
        s_builtInLogger?.Info(result.Result.ToString());


        //// INHERITED
        //MultiplyResult result3D = await calculator.Multiply3DAsync(new Multiply3DRequest { X = 15, Y = 3, Z = 2 });
        //m_builtInLogger.Info(result3D.Result?.ToString);
        //Test2 for channel fail and recovery next(stop - and - start the server)
        //for (int i = 0; i < 100; i++)
        //  {
        //    await Task.Delay(1000);
        //    try
        //    {
        //      MultiplyResult result = await calculator.MultiplyAsync(new MultiplyRequest { X = 15, Y = 3 });
        //      m_builtInLogger.Info(result.Result.ToString());
        //    }
        //    catch (Exception e)
        //    {
        //      m_builtInLogger.Error(e.Message);
        //    }
        //  }

        // Test3 - send cancellation token in an optional parameter (deadlines, headres etc), use server streaming
        //ITimeService timeService = callInvoker.CreateGrpcService<ITimeService>();
        // Needs for async enumerates and C#8+
        //var cancel = new CancellationTokenSource(TimeSpan.FromMinutes(1));
        //var options = new CallOptions(cancellationToken: cancel.Token);
        //await foreach (var time in timeService.SubscribeAsync(options))
        //{
        //  m_builtInLogger.Info(($"The time is now: {time.Time}");
        //}

        Console.ReadKey();
      }
      catch (Exception ex)
      {
        s_builtInLogger?.Error(ex.ToString());
      }
      finally
      {
        await channel.ShutdownAsync();
      }
    }

    /// <summary> Creates an <see cref="AsyncAuthInterceptor"/> that will use given access token as authorization. </summary>
    /// <param name="accessToken">OAuth2 access token.</param>
    /// <returns>The interceptor.</returns>
    public static AsyncAuthInterceptor AccessTokenInterceptor(string accessToken)
    {
      return new AsyncAuthInterceptor((context, metadata) =>
      {
        metadata.Add("authorization", "Bearer " + accessToken);
        return Task.CompletedTask;
      });
    }
  }
}
