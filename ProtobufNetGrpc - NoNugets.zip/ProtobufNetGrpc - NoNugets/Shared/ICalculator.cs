﻿using ProtoBuf.Grpc;
using Shared.Dto;
using System.ServiceModel;
using System.Threading.Tasks;

namespace Shared
{
  [ServiceContract(Name = "Pitram6.Calculator")]
  public interface ICalculator
  {
    /// <param name="request"></param>
    /// <param name="context">
    /// The client can now provide this additional detail by passing
    /// in a CallContext with the CallOptions that describe the needs.
    /// </param>
    /// <returns></returns>
    Task<MultiplyResult> MultiplyAsync(MultiplyRequest request, CallContext context = default);
    Task<MultiplyResult> Multiply3DAsync(Multiply3DRequest request);
  }
}
