﻿using System;
using System.Threading.Tasks;
using ProtoBuf.Grpc;
using Shared;
using Shared.Dto;

namespace Server
{
  /// <summary> Server implementation for <c>ICalculator</c> </summary>
  public class Calculator : ICalculator
  {
    public Task<MultiplyResult> Multiply3DAsync(Multiply3DRequest request)
    {
      Console.WriteLine($"Calling with {request.X} and {request.Y} and {request.Z} ");
      return Task.FromResult(new MultiplyResult { Result = request.X * request.Y * request.Z });
    }

    public Task<MultiplyResult> MultiplyAsync(MultiplyRequest request, CallContext context = default)
    {
      string value = context.RequestHeaders.GetString("SomeHeader");
      Console.WriteLine($"Extract SomeHeader : {value}");
      value = context.RequestHeaders.GetString("Authorization");
      Console.WriteLine($"Extract Authorization : {value}");
      value = context.RequestHeaders.GetString("ServerInterceptor");
      Console.WriteLine($"Extract ServerInterceptor : {value}");
      

      //var state = context.State as string;
      //Console.WriteLine($"Magic bag : {string.Join(" ", state)}");

      var req3d = request as Multiply3DRequest;
      if (req3d != null)
      {
        Console.WriteLine($"Calling with {req3d.X} and {req3d.Y}  and {req3d.Z}");
        return Task.FromResult(new MultiplyResult { Result = req3d.X * req3d.Y * req3d.Z});
      }
      Console.WriteLine($"Calling with {request.X} and {request.Y}");
      return Task.FromResult(new MultiplyResult { Result = request.X * request.Y });
    }
  }
}
