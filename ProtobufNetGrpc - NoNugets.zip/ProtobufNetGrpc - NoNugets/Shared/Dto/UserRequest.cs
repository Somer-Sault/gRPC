﻿using System.Runtime.Serialization;

namespace Shared.Dto
{
  [DataContract]
  public class UserRequest
  {
    [DataMember(Order = 1)]
    public string Name { get; set; }

    [DataMember(Order = 2)]
    public string Password { get; set; }
  }
}
