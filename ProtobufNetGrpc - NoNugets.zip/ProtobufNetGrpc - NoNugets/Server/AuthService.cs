﻿using System.Threading.Tasks;
using Shared;
using Shared.Dto;

namespace Server
{
  /// <summary>  Server implementation for <c>IAuth</c> </summary>
  public class AuthService : IAuth
  {
    public Task<string> SignInAsync(UserRequest userRequest) => Task.FromResult($"{userRequest.Name}{userRequest.Password}");
  }
}
