﻿using Grpc.Core;
using Grpc.Core.Interceptors;
using System;
using System.Threading.Tasks;

namespace Server.Interceptors
{
  /// <summary>
  /// DOCS
  /// https://github.com/grpc/grpc/blob/618a3f561d4a93f263cca23abad086ed8f4d5e86/src/csharp/Grpc.Core.Tests/Interceptors/ServerInterceptorTest.cs
  /// </summary>
  internal class ServerCallContextInterceptor : Interceptor
  {
    readonly Action<ServerCallContext> m_interceptor;

    public ServerCallContextInterceptor(Action<ServerCallContext> interceptor)
    {
      m_interceptor = interceptor;
    }

    public override Task<TResponse> UnaryServerHandler<TRequest, TResponse>(TRequest request, ServerCallContext context, UnaryServerMethod<TRequest, TResponse> continuation)
    {
      m_interceptor(context);
      return continuation(request, context);
    }

    //public override Task<TResponse> ClientStreamingServerHandler<TRequest, TResponse>(IAsyncStreamReader<TRequest> requestStream, ServerCallContext context, ClientStreamingServerMethod<TRequest, TResponse> continuation)
    //{
    //  m_interceptor(context);
    //  return continuation(requestStream, context);
    //}

    //public override Task ServerStreamingServerHandler<TRequest, TResponse>(TRequest request, IServerStreamWriter<TResponse> responseStream, ServerCallContext context, ServerStreamingServerMethod<TRequest, TResponse> continuation)
    //{
    //  m_interceptor(context);
    //  return continuation(request, responseStream, context);
    //}

    //public override Task DuplexStreamingServerHandler<TRequest, TResponse>(IAsyncStreamReader<TRequest> requestStream, IServerStreamWriter<TResponse> responseStream, ServerCallContext context, DuplexStreamingServerMethod<TRequest, TResponse> continuation)
    //{
    //  m_interceptor(context);
    //  return continuation(requestStream, responseStream, context);
    //}
  }
}
